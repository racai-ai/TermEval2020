# ACTER Annotated Corpora for Term Extraction Research, version 1.1

Readme accompanying version 1.1 of the ACTER dataset. This is the version used for the TermEval 2020 shared task, for which the domain of heart failure was used as test data. The current version includes the texts for the heart failure domain, but not yet the gold standard annotations.

* *Creator*: Ayla Rigouts Terryn (LT3 Language and Translation Technology Team, Ghent University)
* *Date of creation version 1.0*: 17/12/2019
* *Date of creation current version 1.1*: 03/02/2020 * *Last updated*: 28/02/2020
* *Contact*: ayla.rigoutsterryn@ugent.be
* *Context*: First edition (2020) of the TermEval shared task on automatic term extraction, organised with the CompuTerm workshop alongside LREC2020 in Marseille. This release contains the data in all domains, including heart failure, the test domain for the TermEval 2020 shared task. The gold standard annotations for heart failure have not been included yet, but will be released simultaneously with the results of the shared task.
* *Source*: https://termeval.ugent.be 


## 1. Contents

The current document should be located in a (compressed) project, where the file structure under each language folder ("en", "fr", and "en") is identical:

```
ACTER_version1_1_incl_test
│   README_ACTER_version1_1.md
│   sources.csv
│
└───en
│   └───corp
│   |   └───annotations
│   |   |   |   corp_en_terms.ann
│   |   |   |   corp_en_terms_nes.ann
│   |   | 
│   |   └───texts
|   |       └───annotated
│   |       |   corp_en_01.txt
│   |       |   corp_en_02.txt
│   |       |   ...
│   |       |
|   |       └───unannotated
│   |           |   corp_en_03.txt
│   |           |   ...
|   |
│   └───equi (equivalent to "corp")
|   |
│   └───hf (equivalent to "corp", except without annotations)
|   |
│   └───wind (equivalent to "corp")
|
└───fr (equivalent to "en")
└───nl (equivalent to "en")
```

As can be seen, there are corpora in three languages (English ("en"), French ("fr"), and Dutch ("nl")).

For each language, there are corpora in four domains (corruption ("corp"), equitation-dressage ("equi"), heart failure ("hf"), and wind energy ("wind")).

The corpora are all comparable (similar in subject, style, length but no translations, so not alignable), except the domain of corruption, which is a parallel (aligned translations) corpus.

For each part of the corpus, the plain text files are included and the annotations. There are two annotation files: one with only the term annotations, and one with term and named entity annotations. The plain text files are split into those which have been annotated and those that have not been annotated. This means that all annotations were found in the former part of the corpus and the latter may contain many more terms which are not (yet) in the gold standard. The file names always mention the subject and language codes.

There is a single case where a text has been annotated only partially: wind_fr_06; therefore the text has been split and the unannotated part is called wind_fr_06bis.

In addition, there is this readme file and a txt-file with the sources of all corpora.


## 2. Annotations

### 2.1 Format

The annotations are provided in simple utf-8 encoded plain text files, with one annotation per line.

The term annotation files include all the term annotations (Specific Terms, Common Terms, and OOD Terms have been combined, so there are currently no further distinctions between different kinds of terms). A separate file (terms_nes) includes both terms and Named Entities.


### 2.2 Casing, POS-tagging, and Lemmatisation
 
True-casing, POS-tagging & lemmatisation are non-trivial tasks but not the focus of this edition of TermEval. Therefore, all data will be lower-cased, non-lemmatised, and with only one entry per term. 

For example, the English corpus on dressage contains the term “bent” (verb – past tense of “to bend”), but also “Bent” (proper noun – person name). While both capitalisation and POS differ, and “bent” is not the lemmatised form, there will be only one entry: “bent” (lowercased) in the gold standard (other full forms of the verb “to bend” have separate entries, if they are present and annotated in the corpus). Systems that do offer lemmatisation should take care to submit the full forms for the evaluation, rather than only the lemmatised form.


## 3. Additional Information

* For more information about the TermEval shared task, visit: https://termeval.ugent.be
* For more information about the CompuTerm workshop, visit: https://sites.google.com/view/computerm2020/
* For more information about the annotation guidelines, visit: http://hdl.handle.net/1854/LU-8503113

Two papers have been published on different aspects of the dataset:
* Rigouts Terryn, A., Hoste, V., & Lefever, E. (2018). A Gold Standard for Multilingual Automatic Term Extraction from Comparable Corpora: Term Structure and Translation Equivalents. Proceedings of LREC 2018. Presented at the Miyazaki, Japan. Miyazaki, Japan: ELRA.
* Rigouts Terryn, A., Hoste, V., & Lefever, E. (2019). In No Uncertain Terms: A Dataset for Monolingual and Multilingual Automatic Term Extraction from Comparable Corpora. Language Resources and Evaluation, 1–34. https://doi.org/10.1007/s10579-019-09453-9

Another paper on the current version of the dataset and the shared task will be published as well:
* Rigouts Terryn, A., Drouin, P., Hoste, V., & Lefever, E. (2020). TermEval 2020: Shared Task on Automatic Term Extraction Using the Annotated Corpora for Term Extraction Research (ACTER) Dataset. Proceedings of CompuTerm 2020.

The dataset has been updated since the publication of the former two papers and those also discuss aspects of the data which have not been made available yet, so make sure to check the most up-to-date information!

\#Annotations per corpus: first term annotations, then term + Named Entity annotations:
* corp	en	927	    1174
* equi	en	1155	1575
* wind	en	1091	1534
* corp	fr	982	    1217
* equi	fr	963	    1183
* wind	fr	773	    968
* corp	nl	1047	1295
* equi	nl	1395	1546
* wind	nl	940	    1245


## 4. Updates

*Changes version 1.0 > version 1.1*
+ inclusion of heart failure texts.

* English corpora:
    * corruption:
        * Removed 1 NE: 'com(2007) 805 final'
    * wind
        * Removed 2 terms: 'variable pitch blades', 'renewable sources'
        * Removed 1 NE: 'skuodas'
* French corpora:
    * corruption:
        * Removed 2 terms: 'indélicat', 'loi relative à la corruption'
    * equitation-dressage:
        * Removed 2 terms: 'canons', 'équilibration'
    * wind energy
        * Added 1 term: 'systèmes mutisources-multistockages'
        * Removed 4 terms: 'systèmes mutisources', 'quadrature', 'inductance directe', 'résistance statorique'
        * Removed 98 NEs: 'bar', 'esk', 'akh', 'tht', 'enbw', 'rich', 'kama', 'man', 'sab', 'mer', 'deg', 'mor', 'aba', 'abo', 'ana', 'azm', 'joo', 'jen', 'pri', 'han', 'ree', 'dav', 'cou', 'hol', 'sau', 'lal', 'lei', 'vet', 'pur', 'per', 'her', 'hau', 'ans', 'slo', 'win', 'thi', 'ela', 'stem', 'cer', 'lav', 'ack', 'e.on', 'cim', 'luo', 'wik', 'ds1103', 'fag', 'and', 'alm', 'pan', 'rap', 'ric', 'saa', 'reb', 'bor', 'kin', 'sem', 'ecr', 'fau', 'ukt', 'kun', 'creg', 'sal', 'bou', 'crap', 'mog', 'nget', 'stu', 'sei', 'lec', 'dir', 'nor', 'abb', 'doh', 'rwe', 'mul', 'oud', 'bea', '96/92/ce', 'gar', 'eri', 'cal', 'goi', 'ish', 'fra', 'cra', 'bna', 'ull', 'des', 'ips', 'dro', 'uct', 'mat', 'ds 1104', 'mar', 'svk', 'bla', 'buh'
* Dutch corpora:
    * corruption:
        * Added 1 term: 'anticorruptie-eenheid'
        * Removed 4 terms: 'verslagen corruptiebestrijding', 'auditdiensten', 'anticorruptie', 'wet betreffende de omkoping'
    * equitation-dressage:
        * Removed 2 terms: 'promotie', 'stuw'
    * wind energy:
        * Removed 2 terms: 'windturbines een horizontale as', 'power coefficient'

